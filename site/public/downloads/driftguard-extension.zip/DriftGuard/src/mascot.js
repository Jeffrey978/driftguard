const MOODS = new Set(["idle", "happy", "alert", "thinking", "sleepy", "celebrate"]);

let seq = 0;

export function mascotMarkup(mood = "idle", options = {}) {
  const resolved = MOODS.has(mood) ? mood : "idle";
  const size = Number(options.size) || 88;
  const uid = options.id || `ember-${++seq}`;
  const label = options.label || "Ember, the DriftGuard companion";
  const compact = size <= 48;

  return `
<svg class="ember${compact ? " ember--compact" : ""}" data-mood="${resolved}" viewBox="0 0 240 240" width="${size}" height="${size}" role="img" aria-label="${escapeAttr(label)}" overflow="visible" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <radialGradient id="${uid}-body" cx="38%" cy="28%" r="72%">
      <stop offset="0" stop-color="#FFE7C4"/>
      <stop offset=".42" stop-color="#E8B889"/>
      <stop offset=".78" stop-color="#E08A6A"/>
      <stop offset="1" stop-color="#D46A56"/>
    </radialGradient>
    <radialGradient id="${uid}-belly" cx="50%" cy="40%" r="70%">
      <stop offset="0" stop-color="#FFF8E8"/>
      <stop offset=".7" stop-color="#F8E2B8"/>
      <stop offset="1" stop-color="#E8B889" stop-opacity=".15"/>
    </radialGradient>
    <linearGradient id="${uid}-flame" x1="50%" y1="100%" x2="50%" y2="0%">
      <stop offset="0" stop-color="#E5624E"/>
      <stop offset=".38" stop-color="#F4BD49"/>
      <stop offset=".72" stop-color="#5EC4B8"/>
      <stop offset="1" stop-color="#1F9C8D"/>
    </linearGradient>
    <linearGradient id="${uid}-visor" x1="50%" y1="0%" x2="50%" y2="100%">
      <stop offset="0" stop-color="#4AA39A"/>
      <stop offset="1" stop-color="#2A736E"/>
    </linearGradient>
    <filter id="${uid}-glow" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="2.4" result="b"/>
      <feMerge>
        <feMergeNode in="b"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
    <filter id="${uid}-soft" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="1.1"/>
    </filter>
  </defs>
  <style>
    .ember { display: block; }
    .ember .float { animation: ember-float 3.2s ease-in-out infinite; transform-origin: 100px 230px; }
    .ember .shadow { animation: ember-shadow 3.2s ease-in-out infinite; transform-origin: 100px 236px; }
    .ember .flame { animation: ember-flicker 1.5s ease-in-out infinite; transform-origin: 100px 54px; }
    .ember .belly { animation: ember-glow 2.8s ease-in-out infinite; }
    .ember .eyes-open { animation: ember-blink 4.8s ease-in-out infinite; transform-origin: 100px 118px; }
    .ember .arm-l { transform-origin: 50px 146px; animation: ember-arm-l 3.2s ease-in-out infinite; }
    .ember .arm-r { transform-origin: 150px 146px; animation: ember-arm-r 3.2s ease-in-out infinite; }
    .ember .arm-up { display: none; }
    .ember .arm-up-l { transform-origin: 52px 138px; }
    .ember .arm-up-r { transform-origin: 148px 138px; }
    .ember .mouth-idle, .ember .mouth-happy, .ember .mouth-alert, .ember .mouth-think, .ember .mouth-sleepy,
    .ember .eyes-shut, .ember .stars, .ember .sparkles, .ember .zzz, .ember .dots, .ember .hand-think { display: none; }
    .ember .mouth-idle { display: block; }

    .ember[data-mood="happy"] .float { animation: ember-bounce 1.35s ease-in-out infinite; }
    .ember[data-mood="happy"] .arm-l, .ember[data-mood="happy"] .arm-r { display: none; }
    .ember[data-mood="happy"] .arm-up { display: block; }
    .ember[data-mood="happy"] .arm-up-l { animation: ember-cheer-l 1.35s ease-in-out infinite; }
    .ember[data-mood="happy"] .arm-up-r { animation: ember-cheer-r 1.35s ease-in-out infinite; }
    .ember[data-mood="happy"] .mouth-idle { display: none; }
    .ember[data-mood="happy"] .mouth-happy { display: block; }
    .ember[data-mood="happy"] .stars { display: block; }

    .ember[data-mood="celebrate"] .float { animation: ember-hop 0.7s ease-in-out infinite; }
    .ember[data-mood="celebrate"] .arm-l, .ember[data-mood="celebrate"] .arm-r { display: none; }
    .ember[data-mood="celebrate"] .arm-up { display: block; }
    .ember[data-mood="celebrate"] .arm-up-l { animation: ember-cheer-l 0.7s ease-in-out infinite; }
    .ember[data-mood="celebrate"] .arm-up-r { animation: ember-cheer-r 0.7s ease-in-out infinite; }
    .ember[data-mood="celebrate"] .mouth-idle { display: none; }
    .ember[data-mood="celebrate"] .mouth-happy { display: block; }
    .ember[data-mood="celebrate"] .stars, .ember[data-mood="celebrate"] .sparkles { display: block; }
    .ember[data-mood="celebrate"] .sparkle { animation: ember-sparkle 1.1s ease-in-out infinite; transform-origin: center; }

    .ember[data-mood="alert"] .float { animation: ember-peek 2.1s ease-in-out infinite; }
    .ember[data-mood="alert"] .flame { animation: ember-flicker-hot 0.7s ease-in-out infinite; }
    .ember[data-mood="alert"] .mouth-idle { display: none; }
    .ember[data-mood="alert"] .mouth-alert { display: block; }
    .ember[data-mood="alert"] .eyes-open { animation: none; }

    .ember[data-mood="thinking"] .mouth-idle { display: none; }
    .ember[data-mood="thinking"] .mouth-think { display: block; }
    .ember[data-mood="thinking"] .dots { display: block; }
    .ember[data-mood="thinking"] .hand-think { display: block; }
    .ember[data-mood="thinking"] .arm-l { animation: none; opacity: 0; }
    .ember[data-mood="thinking"] .dot { animation: ember-dot 1.4s ease-in-out infinite; }

    .ember[data-mood="sleepy"] .float { animation: ember-sway 4.4s ease-in-out infinite; }
    .ember[data-mood="sleepy"] .flame { animation: ember-flicker 2.6s ease-in-out infinite; transform: scale(.86); }
    .ember[data-mood="sleepy"] .eyes-open { display: none; animation: none; }
    .ember[data-mood="sleepy"] .eyes-shut { display: block; }
    .ember[data-mood="sleepy"] .mouth-idle { display: none; }
    .ember[data-mood="sleepy"] .mouth-sleepy { display: block; }
    .ember[data-mood="sleepy"] .zzz { display: block; }
    .ember[data-mood="sleepy"] .z { animation: ember-z 2.8s ease-in-out infinite; }

    .ember--compact .badge, .ember--compact .sparkles, .ember--compact .zzz, .ember--compact .dots { display: none !important; }

    @keyframes ember-float {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-7px); }
    }
    @keyframes ember-shadow {
      0%, 100% { transform: scaleX(1); opacity: .16; }
      50% { transform: scaleX(.78); opacity: .08; }
    }
    @keyframes ember-flicker {
      0%, 100% { transform: scale(1) rotate(-3deg); }
      50% { transform: scale(1.08, 1.16) rotate(4deg); }
    }
    @keyframes ember-flicker-hot {
      0%, 100% { transform: scale(1.06, 1.18) rotate(-6deg); }
      50% { transform: scale(1.18, 1.32) rotate(7deg); }
    }
    @keyframes ember-glow {
      0%, 100% { opacity: .92; }
      50% { opacity: 1; }
    }
    @keyframes ember-blink {
      0%, 41%, 47%, 100% { transform: scaleY(1); }
      44% { transform: scaleY(.08); }
    }
    @keyframes ember-arm-l {
      0%, 100% { transform: rotate(4deg); }
      50% { transform: rotate(-6deg); }
    }
    @keyframes ember-arm-r {
      0%, 100% { transform: rotate(-4deg); }
      50% { transform: rotate(6deg); }
    }
    @keyframes ember-bounce {
      0%, 100% { transform: translateY(0) scale(1); }
      50% { transform: translateY(-9px) scale(1.03, .97); }
    }
    @keyframes ember-hop {
      0%, 100% { transform: translateY(0) rotate(-2deg); }
      50% { transform: translateY(-14px) rotate(2deg); }
    }
    @keyframes ember-peek {
      0%, 100% { transform: translateY(0) rotate(0); }
      40% { transform: translateY(-4px) rotate(-5deg); }
      70% { transform: translateY(-2px) rotate(4deg); }
    }
    @keyframes ember-sway {
      0%, 100% { transform: translateY(2px) rotate(-4deg); }
      50% { transform: translateY(-2px) rotate(4deg); }
    }
    @keyframes ember-cheer-l {
      0%, 100% { transform: rotate(-8deg); }
      50% { transform: rotate(10deg); }
    }
    @keyframes ember-cheer-r {
      0%, 100% { transform: rotate(8deg); }
      50% { transform: rotate(-10deg); }
    }
    @keyframes ember-sparkle {
      0%, 100% { opacity: .2; transform: scale(.7) rotate(0); }
      50% { opacity: 1; transform: scale(1.1) rotate(20deg); }
    }
    @keyframes ember-z {
      0%, 100% { opacity: .15; transform: translateY(0); }
      50% { opacity: .85; transform: translateY(-6px); }
    }
    @keyframes ember-dot {
      0%, 100% { opacity: .2; }
      50% { opacity: 1; }
    }
    @media (prefers-reduced-motion: reduce) {
      .ember .float, .ember .shadow, .ember .flame, .ember .belly,
      .ember .eyes-open, .ember .arm-l, .ember .arm-r, .ember .sparkle, .ember .z, .ember .dot {
        animation: none !important;
      }
    }
  </style>

  <g transform="translate(20,-4)">
  <ellipse class="shadow" cx="100" cy="236" rx="46" ry="7" fill="#000"/>

  <g class="float">
    <g class="sparkles" fill="#F4BD49">
      <path class="sparkle" d="M34 86l1.4 4.2 4.2 1.4-4.2 1.4-1.4 4.2-1.4-4.2-4.2-1.4 4.2-1.4z"/>
      <path class="sparkle" d="M168 74l1.1 3.4 3.4 1.1-3.4 1.1-1.1 3.4-1.1-3.4-3.4-1.1 3.4-1.1z" style="animation-delay:.2s"/>
      <path class="sparkle" d="M166 168l1.5 4.6 4.6 1.5-4.6 1.5-1.5 4.6-1.5-4.6-4.6-1.5 4.6-1.5z" style="animation-delay:.45s"/>
      <path class="sparkle" d="M28 160l1 3 3 1-3 1-1 3-1-3-3-1 3-1z" style="animation-delay:.7s"/>
    </g>

    <g class="zzz" fill="#C9BBA8" font-family="ui-sans-serif, system-ui, sans-serif" font-weight="800">
      <text class="z" x="148" y="58" font-size="16">z</text>
      <text class="z" x="162" y="42" font-size="13" style="animation-delay:.5s">z</text>
      <text class="z" x="174" y="28" font-size="10" style="animation-delay:1s">z</text>
    </g>

    <g class="dots" fill="#9AA8A3">
      <circle class="dot" cx="154" cy="52" r="3.2"/>
      <circle class="dot" cx="166" cy="40" r="4" style="animation-delay:.2s"/>
      <circle class="dot" cx="180" cy="30" r="5" style="animation-delay:.4s"/>
    </g>

    <g class="flame" filter="url(#${uid}-glow)">
      <path d="M100 54 C84 42 80 22 94 8 C99 1 110 4 112 16 C122 10 120 32 100 54 Z" fill="url(#${uid}-flame)"/>
      <path d="M100 54 C90 44 88 28 97 16 C101 10 108 14 107 24 C106 34 103 46 100 54 Z" fill="#FFE7A8"/>
    </g>

    <rect x="93" y="50" width="14" height="11" rx="3" fill="#3A2F28"/>
    <rect x="90" y="48" width="20" height="6" rx="2.5" fill="#2A221C"/>

    <g class="visor" transform="rotate(-7 100 76)">
      <path d="M56 74 C56 62 72 54 100 54 C128 54 144 62 144 74 L141 86 C141 92 59 92 59 86 Z" fill="url(#${uid}-visor)" stroke="#1E4F4C" stroke-width="1.6" stroke-linejoin="round"/>
      <path d="M70 80 H130" stroke="#1A5552" stroke-width="1.15" stroke-linecap="round" stroke-dasharray="3.2 2.6" fill="none" opacity=".85"/>
    </g>

    <path d="M100 72 C136 72 160 100 162 142 C164 184 140 216 100 220 C60 216 36 184 38 142 C40 100 64 72 100 72 Z" fill="url(#${uid}-body)" stroke="#3D2C24" stroke-width="2.8" stroke-linejoin="round"/>

    <path class="arm-l" d="M46 140 C18 148 12 176 28 192 C36 200 52 188 56 168 C58 152 54 138 46 140 Z" fill="url(#${uid}-body)" stroke="#3D2C24" stroke-width="2.4" stroke-linejoin="round"/>
    <path class="arm-r" d="M154 140 C182 148 188 176 172 192 C164 200 148 188 144 168 C142 152 146 138 154 140 Z" fill="url(#${uid}-body)" stroke="#3D2C24" stroke-width="2.4" stroke-linejoin="round"/>
    <path class="arm-up arm-up-l" d="M50 138 C28 118 22 88 40 74 C50 66 64 80 62 104 C61 122 56 134 50 138 Z" fill="url(#${uid}-body)" stroke="#3D2C24" stroke-width="2.4" stroke-linejoin="round"/>
    <path class="arm-up arm-up-r" d="M150 138 C172 118 178 88 160 74 C150 66 136 80 138 104 C139 122 144 134 150 138 Z" fill="url(#${uid}-body)" stroke="#3D2C24" stroke-width="2.4" stroke-linejoin="round"/>

    <g class="hand-think">
      <path d="M48 156 C32 146 34 124 54 122 C66 120 76 134 70 148 C66 160 58 164 48 156 Z" fill="url(#${uid}-body)" stroke="#3D2C24" stroke-width="2.4" stroke-linejoin="round"/>
    </g>

    <ellipse class="belly" cx="100" cy="186" rx="46" ry="28" fill="url(#${uid}-belly)"/>
    <ellipse cx="78" cy="96" rx="18" ry="10" fill="#fff" opacity=".22" transform="rotate(-28 78 96)"/>

    <ellipse cx="62" cy="138" rx="13" ry="8" fill="#F08A7A" opacity=".72"/>
    <ellipse cx="138" cy="138" rx="13" ry="8" fill="#F08A7A" opacity=".72"/>

    <g class="eyes-open">
      <ellipse cx="78" cy="118" rx="15" ry="17.5" fill="#1A1814"/>
      <ellipse cx="122" cy="118" rx="15" ry="17.5" fill="#1A1814"/>
      <circle cx="72" cy="111" r="5.4" fill="#FFFAF0"/>
      <circle cx="116" cy="111" r="5.4" fill="#FFFAF0"/>
      <circle cx="81" cy="121" r="2" fill="#FFFAF0" opacity=".75"/>
      <circle cx="125" cy="121" r="2" fill="#FFFAF0" opacity=".75"/>
      <g class="stars" fill="#FFF4C4">
        <path d="M78 116l1.1 3.2 3.2 1.1-3.2 1.1-1.1 3.2-1.1-3.2-3.2-1.1 3.2-1.1z"/>
        <path d="M122 116l1.1 3.2 3.2 1.1-3.2 1.1-1.1 3.2-1.1-3.2-3.2-1.1 3.2-1.1z"/>
      </g>
    </g>

    <g class="eyes-shut" fill="none" stroke="#1A1814" stroke-width="3.2" stroke-linecap="round">
      <path d="M64 118 Q78 128 92 118"/>
      <path d="M108 118 Q122 128 136 118"/>
    </g>

    <path class="mouth-idle" d="M90 144 Q100 152 110 144" fill="none" stroke="#1A1814" stroke-width="3.1" stroke-linecap="round"/>
    <g class="mouth-happy">
      <path d="M88 142 Q100 162 112 142 Q100 150 88 142 Z" fill="#1A1814"/>
      <ellipse cx="100" cy="152" rx="5.5" ry="3.4" fill="#E5624E"/>
    </g>
    <ellipse class="mouth-alert" cx="100" cy="148" rx="5.2" ry="6.4" fill="#1A1814"/>
    <ellipse class="mouth-think" cx="104" cy="148" rx="3.4" ry="4.2" fill="#1A1814"/>
    <path class="mouth-sleepy" d="M92 146 Q100 150 108 146" fill="none" stroke="#1A1814" stroke-width="3" stroke-linecap="round"/>

    <g class="badge">
      <circle cx="134" cy="172" r="12" fill="#FFF6E8" stroke="#C9A46A" stroke-width="2.2"/>
      <circle cx="134" cy="172" r="8.2" fill="none" stroke="#2F7A78" stroke-width=".9"/>
      <polygon points="134,164 136.2,172 134,180 131.8,172" fill="#E5624E"/>
      <polygon points="126,172 134,169.8 142,172 134,174.2" fill="#2F7A78"/>
      <circle cx="134" cy="172" r="2.1" fill="#FFF6E8" stroke="#C9A46A" stroke-width="1"/>
    </g>

    <ellipse cx="82" cy="222" rx="15" ry="8.5" fill="#D4785C" stroke="#3D2C24" stroke-width="2.2"/>
    <ellipse cx="118" cy="222" rx="15" ry="8.5" fill="#D4785C" stroke="#3D2C24" stroke-width="2.2"/>
  </g>
  </g>
</svg>`.trim();
}

export function setMascotMood(svg, mood) {
  if (!svg) return;
  svg.setAttribute("data-mood", MOODS.has(mood) ? mood : "idle");
}

function escapeAttr(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;");
}

// The one place the extension maps moods to image files (used where inline SVG
// can't go, e.g. the in-page prompt and notifications). Swap art here.
export const MASCOT_FILES = {
  idle: "assets/mascot/idle.svg",
  happy: "assets/mascot/happy.svg",
  alert: "assets/mascot/alert.svg",
  sleepy: "assets/mascot/sleepy.svg",
  celebrate: "assets/mascot/celebrate.svg",
  thinking: "assets/mascot/thinking.svg"
};

export function mascotPath(mood = "idle") {
  return MASCOT_FILES[mood] || MASCOT_FILES.idle;
}

export function mascotUrl(mood = "idle") {
  const path = mascotPath(mood);
  return typeof chrome !== "undefined" && chrome.runtime?.getURL ? chrome.runtime.getURL(path) : `../${path}`;
}

export function hydrateMascots(root = document) {
  root.querySelectorAll("[data-mascot]").forEach((el) => {
    const mood = el.getAttribute("data-mascot") || "idle";
    const size = Number(el.getAttribute("data-size")) || 88;
    el.innerHTML = mascotMarkup(mood, { size, id: el.id || undefined });
  });

  const hiButton = root.querySelector("#idleMascotButton");
  const idleSlot = root.querySelector("#idleMascot");
  if (hiButton && idleSlot && !hiButton.dataset.emberBound) {
    hiButton.dataset.emberBound = "1";
    const wave = ["happy", "celebrate", "idle"];
    let i = 0;
    hiButton.addEventListener("click", () => {
      i = (i + 1) % wave.length;
      setMascotSlot(idleSlot, wave[i]);
    });
  }
}

export function setMascotSlot(el, mood) {
  if (!el) return;
  const resolved = MOODS.has(mood) ? mood : "idle";
  el.setAttribute("data-mascot", resolved);
  const svg = el.querySelector("svg.ember");
  if (svg) setMascotMood(svg, resolved);
  else el.innerHTML = mascotMarkup(resolved, { size: Number(el.getAttribute("data-size")) || 88, id: el.id || undefined });
}
